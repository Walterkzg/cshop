package com.example.demo.pojo;

import lombok.Data;

@Data
public class Product {
    private String username;
    private int pid;
    private String pname;
    private int price;
    private int ptype;
    private String photo;
}
