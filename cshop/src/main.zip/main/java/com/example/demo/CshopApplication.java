package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CshopApplication {

    public static void main(String[] args) {
        SpringApplication.run(CshopApplication.class, args);
    }

}
