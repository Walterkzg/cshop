package com.example.demo.pojo;

import lombok.Data;

@Data
public class productAndOrder {
    private int pid;
    private int num;
    private int price;
    private int state;
    private String username;
    private String uname;
    private String oadress;
    private String otime;
    private String oid;
    private String pname;
    private String photo;
}
